package main

import "api/app"

func main() {
	app.StartApp()
}
